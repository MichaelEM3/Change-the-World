# require "rails_helper"

# RSpec.describe "Joining a club" do 
# 	it "joined club successfully" do 
# 		visit (root_path)
# 		fill_in('Username', with: 'test3')
# 		fill_in('Password', with: 'test3')
# 		click_button('Log in')
# 		click_link('Show Me More')
# 		click_button('Join Club')

# 		# expect(page).to have_content('Joined Club successfully')
# end
# end


